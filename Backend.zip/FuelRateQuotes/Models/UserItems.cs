﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FuelRateQuotes.Models
{
    public class Fuel_quote
    {
        public string vehicle_type;
        public double fuel_gallons;
        public double fuel_rate_price;
    }
    public class Fuel_quote_module{}
    public class UserItem
    {
        public long id { get; set; }
        public string username { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string address2 { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string zipcode { get; set; }
        public bool isComplete { get; set; }
        private string password { get; set; }
    }
  
  public class Pricing_module {} //To be determined
    
}
