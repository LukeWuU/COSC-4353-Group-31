Latest developed prototype of the backend web API now with added frontend functionality written in CSS, Javascript, and HTML.

Template based on Microsoft tutorial "Tutorial: Call an ASP.NET Core web API with Javascript", with ASP.NET Core version set to 2.1.

The Web API fulfills basic CRUD actions for Client Profile Management, verified through unit testing in the launch URL: index.html.

The Add and Delete functions under Client Manangement perform successfully. The Edit function is unavailable and still in progress.
 
The classes for user objects and fuel rate quotes are located in the Models folder of the project.

The project uses InMemoryDatabase from the EntityFrameworkCore package to store data. External database to be determined.

Unable to provide code coverage using OpenCover and Report Generator due to .NET core 2.1 compatibility issues.

Missing components as of 3/13/22: 

- Login module with stronger validation measures

- Client profile editing and edit displays

- Fuel Price module with implementation

- Code Coverage report for unit tests. Requires extensive updates for the entire solution. May implement after submission.