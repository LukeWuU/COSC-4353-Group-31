import com.fasterxml.jackson.databind.util.JSONPObject;
import netscape.javascript.JSObject;
import java.sql.*;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet
class AJAXHandler(){

    public AJAXHandler(){
        super();
    }
public static void main(String args[]){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fuelquote_db",
                "root", "root");
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT state, quotes FROM fuelquote_db;");
        while(rs.next()){
            String state = rs.getString("state");
            String history = rs.getObject("quotes");
            System.out.println(state + " " + quotes);
        }
        con.close();
    } catch(Exception error){System.out.println("error");}


}


}


