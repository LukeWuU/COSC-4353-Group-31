DROP SCHEMA IF EXISTS `fuelquote_db`;
CREATE DATABASE `fuelquote_db`
    CHARACTER SET utf8mb4;

-- CREATE USER 'db_user01'@'localhost' IDENTIFIED BY 'myPassIs@123';
-- GRANT ALL PRIVILEGES ON fuelquote_db.* TO 'db_user01'@'localhost';
-- ALTER USER 'db_user01'@'localhost' IDENTIFIED WITH mysql_native_password BY 'myPassIs@123';
-- FLUSH PRIVILEGES;

USE `fuelquote_db`;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`(
    `id` INT NOT NULL AUTO_INCREMENT, 
    `username` VARCHAR (64) NOT NULL UNIQUE,
    `password` VARCHAR (64),
    `role` VARCHAR (10),
    `fullname` VARCHAR (50), 
    `address01` VARCHAR (100),
    `address02` VARCHAR (100), 
    `city` VARCHAR (100),    
    `state` VARCHAR (2), 
    `zipcode` VARCHAR (9),    
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `quote`;
CREATE TABLE `quote`(
    `id` INT NOT NULL AUTO_INCREMENT, 
    `requested_gallon` DOUBLE,
    `delivery_address` VARCHAR (100), 
    `delivery_date` DATETIME,
    `price_per_gallon` DOUBLE, 
    `total_amount` DOUBLE,   
    `user_id` INT NOT NULL, 
    `request_date` DATETIME, 
    PRIMARY KEY (`id`),
    CONSTRAINT `quote_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`(
    `id` INT NOT NULL AUTO_INCREMENT, 
    `name` VARCHAR (100), 
    PRIMARY KEY (`id`),
    CONSTRAINT `role_ibfk_1` FOREIGN KEY (`id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
