Initial Setup Instructions
1. Install MySQL [developed version: 8.0 Community]
	user: 	root
	pw: 	root
2. Create the schema [No need to enter DB details because all are done via Hibernate]:
	
CREATE DATABASE `fuelquote_db`
    CHARACTER SET utf8mb4;

3. Install Intellij IDEA [Developed version: Ultimate 2020.01]

4. Java [OpenJDK 11]

5. Import the application to the IDE and Run the Code.
6. Goto http://localhost:8081

Updates to FuelQuotesApplication as of 5/6/2022:
State validation has been implemented
The validation instructs users to select their state of residence
The value of the client's state is saved as its abbreviation in the database
Users cannot submit their registration info until they have selected a state

Frontend components to allow users to edit or delete their profiles are forthcoming

The pricing module has been implemented but is not accurate in calculating a fuel quote margin
The requested gallons factor has been calculated successfully, according to the amount requested
The rate history factor and location factor have been assigned default values
The rate history factor and location factor must be determined by AJAX calls to the database
The AJAX calls must get the state and at least one fuel quote from the user credentials
