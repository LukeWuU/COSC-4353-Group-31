package com.petrol.fuelquote.controller;

import com.petrol.fuelquote.model.User;
import com.petrol.fuelquote.repository.UserRepository;
import com.petrol.fuelquote.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.AdditionalAnswers.returnsFirstArg;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class UserControllerTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void userRegistrationDto() throws Exception {
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/",
                String.class)).contains("username");
    }

    @Test
    void showRegistrationForm() throws Exception {
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/",
                String.class)).contains("username");
    }

    @Test
    void showRegFormShouldReturnNull() {
        User user = new User();
        UserRepository userRepository = Mockito.mock(UserRepository.class);
        when(userRepository.save(any(User.class))).then(returnsFirstArg());
        userRepository.findByUsername(user.getUsername());
        assertThat(user.getUsername()).isNull();
    }

    @Test
    void registerUser() throws Exception {
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/",
                String.class)).contains("username");
    }

    @Test
    void profile() throws Exception {
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/",
                String.class)).contains("username");
    }

    @Test
    void delete() throws Exception{
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/",
                String.class)).contains("username");
    }

    @Test
    void deleteUsers() throws Exception {
        User user = new User();
        UserController userController = Mockito.mock(UserController.class);
        userController.deleteUsers(user.getId());
    }

    @Test
    void update() throws Exception {
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/",
                String.class)).contains("username");
    }

    @Test
    void updateUser() throws Exception {
        User user = new User();
        UserController userController = Mockito.mock(UserController.class);
        userController.updateUser(user.getId(), user);
    }

    @Test
    void readUsers() throws Exception{
        UserController userController = Mockito.mock(UserController.class);
        userController.readUsers();
    }
}