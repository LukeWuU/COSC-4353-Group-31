package com.petrol.fuelquote.service;

import com.petrol.fuelquote.model.User;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class QuoteServiceImplTest {

    @Test
    void listAll() {
        assertEquals(1,1);
    }

    @Test
    void save() {
        assertEquals(1,1);
    }

    @Test
    void get() {
        assertEquals(1,1);
    }

    @Test
    void listUserQuotes() {
        assertEquals(1,1);
    }

    @Test
    void delete(){
        User user = Mockito.mock(User.class);
        QuoteService quoteService = Mockito.mock(QuoteService.class);
        quoteService.delete(user.getId());
        assertNotNull(user);
    }

    @Test
    void update(){
        User user = Mockito.mock(User.class);
        QuoteService quoteService = Mockito.mock(QuoteService.class);
        quoteService.update(user.getId());
        assertNotNull(user);
    }
}