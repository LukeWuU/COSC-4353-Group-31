Initial Setup Instructions
1. Install MySQL [developed version: 8.0 Community]
	user: 	root
	pw: 	root
2. Create the schema [No need to enter DB details because all are done via Hibernate]:
	
CREATE DATABASE `fuelquote_db`
    CHARACTER SET utf8mb4;

3. Install Intellij IDEA [Developed version: Ultimate 2020.01]

4. Java [OpenJDK 11]

5. Import the application to the IDE and Run the Code.
6. Goto http://localhost:8081

Updates to FuelQuotesApplication
Additional user controller methods added: UPDATE and DELETE
The UserService has been updated to implement additional controller methods
Unit tests conducted to test the new controller methods were successful
Unit tests conducted to test the new service methods were successful
Frontend connectivity to allow users to edit or delete profile are forthcoming
Fuel quote margin factors when calculating fuel quotes are forthcoming

