package com.petrol.fuelquote.service;
import com.petrol.fuelquote.model.User;
import com.petrol.fuelquote.web.dto.UserRegisterationDto;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
        User save(UserRegisterationDto registrationDto);
        User getUserByUsername(String username);
        User deleteUserByUsername(String username);
        User updateUserByUsername(String username);
}
