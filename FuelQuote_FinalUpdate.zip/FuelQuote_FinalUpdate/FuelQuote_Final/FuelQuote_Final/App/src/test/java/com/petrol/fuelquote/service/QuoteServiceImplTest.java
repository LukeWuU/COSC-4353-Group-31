package com.petrol.fuelquote.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class QuoteServiceImplTest {

    @Test
    void listAll() {
        assertEquals(1,1);
    }

    @Test
    void save() {
        assertEquals(1,1);
    }

    @Test
    void get() {
        assertEquals(1,1);
    }

    @Test
    void listUserQuotes() {
        assertEquals(1,1);
    }
}