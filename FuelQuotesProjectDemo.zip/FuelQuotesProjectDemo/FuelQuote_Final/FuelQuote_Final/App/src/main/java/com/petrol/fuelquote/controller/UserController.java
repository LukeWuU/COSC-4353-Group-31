package com.petrol.fuelquote.controller;

import java.util.List;

import com.petrol.fuelquote.model.User;
import com.petrol.fuelquote.repository.UserRepository;
import com.petrol.fuelquote.service.UserService;
import com.petrol.fuelquote.web.dto.UserRegisterationDto;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {


    private UserService userService;

    public UserController(UserService userService) {
        super();
        this.userService = userService;
    }

    @ModelAttribute("user")
    public UserRegisterationDto userRegistrationDto(){
        return new UserRegisterationDto();
    }

    @GetMapping("registration")
    public String showRegistrationForm(){
        return "registration";
    }

    @PostMapping("registration")
    public String registerUser(@ModelAttribute("user")UserRegisterationDto dto){
        userService.save(dto);
        return "redirect:/registration?success";
    }

    @GetMapping("/profile")
    public String profile(Model model){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = "";
        if (principal instanceof UserDetails) {
            username = ((UserDetails)principal).getUsername();
        } else {
            username = principal.toString();
        }
        User currentUser = userService.getUserByUsername(username);
        model.addAttribute("currentUser", currentUser);
        return "profilePage";
    }

    @DeleteMapping("/profile")
    public void deleteUsers(@PathVariable(value = "id") Long id){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = "";
        if (principal instanceof UserDetails) {
            username = ((UserDetails)principal).getUsername();
        } else {
            username = principal.toString();
        }
        userService.deleteUser(id);
    }

    @PutMapping("/profile")
    public User updateUser(@PathVariable(value = "id") Long id, @RequestBody User UserDetails){
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = "";
        if (principal instanceof UserDetails) {
            username = ((UserDetails)principal).getUsername();
        } else {
            username = principal.toString();
        }
        return userService.updateUser(id, UserDetails);
    }

    @GetMapping("user")
    public List<User> readUsers(){
        return userService.getUsers();
    }
}
