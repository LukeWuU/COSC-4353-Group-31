package com.petrol.fuelquote.service;
import com.petrol.fuelquote.model.User;
import com.petrol.fuelquote.web.dto.UserRegisterationDto;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserService extends UserDetailsService {
        User save(UserRegisterationDto registrationDto);
        User getUserByUsername(String username);
        List<User> getUsers();
        void deleteUser(Long id);
        User updateUser(Long id, User UserDetails);
}
