package com.petrol.fuelquote.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.petrol.fuelquote.model.Role;
import com.petrol.fuelquote.model.User;
import com.petrol.fuelquote.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static net.bytebuddy.matcher.ElementMatchers.is;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class UserServiceImplTest {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Test
    void save() {
        assertEquals(1,1);
    }

    @Test
    void getUserByUsername() {
        assertEquals(1,1);
    }

    @Test
    void loadUserByUsername() {
        assertEquals(1,1);
    }

    @Test
    void getUsers(){
        User user = Mockito.mock(User.class);
        UserService userService = Mockito.mock(UserService.class);
        assertNotNull(user);
        assertNotNull(userService.getUsers());
    }

    @Test
    void updateUser(){
        User user = Mockito.mock(User.class);
        UserService userService = Mockito.mock(UserService.class);
        Mockito.when(userService.updateUser(user.getId(), user)).thenReturn(user);
        assertSame((userService.updateUser(user.getId(), user)), null);
    }

    @Test
    void deleteUser(){
        User user = new User();
        user.setId(3L);
        UserService userService = Mockito.mock(UserService.class);
        userService.deleteUser(3L);
        assertNotNull(user);
    }
}