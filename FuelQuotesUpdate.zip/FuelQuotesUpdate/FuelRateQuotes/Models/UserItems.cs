﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FuelRateQuotes.Models
{
    public record Fuel_quote
    {
        public double requested_gallons;
        public string delivery_address;
        public string delivery_date;
        public double fuel_rate_price;
    }
    public class Fuel_quote_module{}
    public class UserItem
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string id { get; set; }
        [BsonElement("Name")]
        [JsonProperty("name")]
        [Required]
        public string name { get; set; }
        public string address { get; set; }
        public string address2 { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string zipcode { get; set; }
        public bool isComplete { get; set; }

        [Required]
        public string username { get; set; }
        private string password { get; set; }
        public IEnumerable<Fuel_quote> fuel_quotes { get; init; }
    }
  
  public class Pricing_module {} //To be determined
    
}
