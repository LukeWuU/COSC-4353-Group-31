﻿using FuelRateQuotes.Models;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;

namespace FuelRateQuotes.Services
{
    public interface IUserService
    {
        public List<UserItem> Get();
        public UserItem Get(string id);
        public UserItem Create(UserItem user);
        public void Update(string id, UserItem user);
        public void Remove(UserItem user);
        public void Remove(string id);     
    }
    public class UserService : IUserService
    {
        private readonly IMongoCollection<UserItem> _userItems;

        public UserService(IFuelQuoteDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);

            _userItems = database.GetCollection<UserItem>(settings.UsersCollectionName);
        }

        public List<UserItem> Get() => _userItems.Find(userItem => true).ToList();

        public UserItem Get(string id) => _userItems.Find<UserItem>(userItem => userItem.id == id).FirstOrDefault();

        public UserItem Create(UserItem userItem)
        {
            _userItems.InsertOne(userItem);
            return userItem;
        }

        public void Update(string id, UserItem userItemIn) =>
            _userItems.ReplaceOne(userItem => userItem.id == id, userItemIn);

        public void Remove(UserItem userItemIn) =>
            _userItems.DeleteOne(userItem => userItem.id == userItemIn.id);

        public void Remove(string id) =>
            _userItems.DeleteOne(userItem => userItem.id == id);
    }
}