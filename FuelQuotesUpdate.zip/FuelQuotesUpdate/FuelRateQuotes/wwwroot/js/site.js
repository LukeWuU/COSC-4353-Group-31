﻿const uri = 'api/UserItems';
const db = 'mongodb://localhost:27017'
let clients = [];

function getItems() {
    fetch(uri)
        .then(response => response.json())
        .then(data => _displayItems(data))
        .catch(error => console.error('Unable to display user(s).', error));
}

function addItem() {
    const addNameTextbox = document.getElementById('add-name');
    const addAddressTextbox = document.getElementById('add-address');
    const addAddress2Textbox = document.getElementById('add-address2');
    const addCityTextbox = document.getElementById('add-city');
    const addStateTextbox = document.getElementById('add-state');
    const addZipcodeTextbox = document.getElementById('add-zipcode');

    const item = {
        isComplete: false,
        name: addNameTextbox.value.trim(),
        address: addAddressTextbox.value.trim(),
        address2: addAddress2Textbox.value.trim(),
        city: addCityTextbox.value.trim(),
        state: addStateTextbox.value.trim(),
        zipcode: addZipcodeTextbox.value.trim()
    };

    fetch(uri, {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(item)
    })
        .then(response => response.json())
        .then(() => {
            getItems();
            addNameTextbox.value = '';
            addAddressTextbox.value = '';
            addAddress2Textbox.value = '';
            addCityTextbox.value = '';
            addStateTextbox.value = '';
            addZipcodeTextbox.value = '';
        })
        .catch(error => console.error('Unable to add item.', error));
}

function deleteItem(id) {
    fetch(`${uri}/${id}`, {
        method: 'DELETE'
    })
        .then(() => getItems())
        .catch(error => console.error('Unable to delete item.', error));
}

function displayEditForm(id) {
    const item = clients.find(item => item.id === id);

    document.getElementById('edit-name').value = item.name;
    document.getElementById('edit-username').value = item.username;
    document.getElementById('edit-id').value = item.id;
    document.getElementById('edit-address').value = item.address;
    document.getElementById('edit-address2').value = item.address_2;
    document.getElementById('edit-city').value = item.city;
    document.getElementById('edit-state').value = item.state;
    document.getElementById('edit-zipcode').value = item.zipcode;
    document.getElementById('edit-isComplete').checked = item.isComplete;
    document.getElementById('editForm').style.display = 'block';
}

function updateItem() {

    const itemId = document.getElementById('edit-id').value;
    const item = {
        id: toString(itemId, 24),
        isComplete: document.getElementById('edit-isComplete').checked,
        name: document.getElementById('edit-name').value.trim(),
        username: document.getElementById('edit-username').value.trim(),
        address: document.getElementById('edit-address').value.trim(),
        address2: document.getElementById('edit-address2').value.trim(),
        city: document.getElementById('edit-city').value.trim(),
        state: document.getElementById('edit-state').value.trim(),
        zipcode: document.getElementById('edit-zipcode').value.trim()
    };

    fetch(`${uri}/${itemId}`, {
        method: 'PUT',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(item)
    })
        .then(() => getItems())
        .catch(error => console.error('Unable to update item.', error));

    closeInput();

    return false;
}

function closeInput() {
    document.getElementById('editForm').style.display = 'none';
}

function _displayCount(itemCount) {
    const name = (itemCount === 1) ? 'client displayed' : 'clients displayed';

    document.getElementById('counter').innerText = `${itemCount} ${name}`;
}

function _displayItems(data) {
    const tBody = document.getElementById('clients');
    tBody.innerHTML = '';

    _displayCount(data.length);

    const button = document.createElement('button');

    data.forEach(item => {
        let isCompleteCheckbox = document.createElement('input');
        isCompleteCheckbox.type = 'checkbox';
        isCompleteCheckbox.disabled = false;
        isCompleteCheckbox.checked = item.isComplete;

        let editButton = button.cloneNode(false);
        editButton.innerText = 'Edit';
        editButton.setAttribute('onclick', `displayEditForm(${item.id})`);

        let deleteButton = button.cloneNode(false);
        deleteButton.innerText = 'Delete';
        deleteButton.setAttribute('onclick', `deleteItem(${item.id})`);

        let tr = tBody.insertRow();

        let td0 = tr.insertCell(0);
        let id = document.createTextNode(item.id);
        td0.appendChild(id);

        let td1 = tr.insertCell(1);
        let name = document.createTextNode(item.name);
        td1.appendChild(name);

        let td2 = tr.insertCell(2);
        let address = document.createTextNode(item.address);
        td2.appendChild(address);        

        let td3 = tr.insertCell(3);
        let address2 = document.createTextNode(item.address2);
        td3.appendChild(address2);

        let td4 = tr.insertCell(4);
        let city = document.createTextNode(item.city);
        td4.appendChild(city);

        let td5 = tr.insertCell(5);
        let state = document.createTextNode(item.state);
        td5.appendChild(state);

        let td6 = tr.insertCell(6);
        let zipcode = document.createTextNode(item.zipcode);
        td6.appendChild(zipcode);

        let td7 = tr.insertCell(7);
        let username = document.createTextNode(item.username);
        td7.appendChild(username);

        let td8 = tr.insertCell(8);
        let password = document.createTextNode(item.password);
        td8.appendChild(password);
    });

    clients = data;
}