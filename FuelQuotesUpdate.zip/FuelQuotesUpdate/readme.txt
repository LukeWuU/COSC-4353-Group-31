Updated version of the project integrating FuelRateQuotes backend with the FuelQuotes_Final frontend.

MongoDB v5.0.6 was chosen and locally installed as the database for the project.

Persistence of information to database was observed and verified using MongoDBCompass.

The backend fulfills basic CRUD actions, verified through testing in Postman.

The loginFunction() and addLoginItem() functions in login.html adds a username to the database.

The recommended action for login.html is to match the username and password entries to an existing user's info in the database.

The creation of clients and its persistence to the database from the registration.html page is still in progress.

Unable to persist info to database in registration.html, possibly due to differences in backend framework.

The webpage hidden_index.html displays the current information stored in the database. Not accessible to users.

The FuelRateQuotesUnitTest files were excluded from this upload since no changes were made to any of the unit test files.

The FuelRateQuotesUnitTest files can be reuploaded from the FuelRateQuotesUpdate submission and reused for this project.

Missing components as of 4/22/22: 

- Login module with stronger validation measures

- Client profile editing capabilities and edit displays

- Client profile deletion capabilities

- Fuel Pricing module with implementation