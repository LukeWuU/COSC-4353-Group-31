A more developed prototype of the backend web API now with added frontend functionality written in CSS, Javascript, and HTML.

Template based on Microsoft tutorial "Tutorial: Call an ASP.NET Core web API with Javascript", with ASP.NET Core version set to 3.1.

Package installed for this current prototype is Microsoft.Typescript.MSBuild version 4.6.2.

The Web API fulfills basic CRUD actions for Client Profile Management, verified through unit testing in the launch URL: index.html.
 
The classes for user objects and fuel rate quotes are located in the Models folder of the project.

The project uses InMemoryDatabase from the EntityFrameworkCore package to store data. External database to be determined.

Missing components as of 3/10/22: Login module with validation, client profile editing, and Fuel Price module with implementation details.