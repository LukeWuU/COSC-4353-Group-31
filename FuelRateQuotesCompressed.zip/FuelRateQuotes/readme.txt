Early prototype of the Fuel Rate Quote web API for the backend portion of the project written in C#.

Template based on a Microsoft "Create a Web API with ASP.NET Core" tutorial, with ASP.NET Core version set to 2.1.

NuGet Packages installed for the project are of version 2.1.14.

The Web API fulfills basic CRUD actions for users(clients), verified through testing in Postman.
 
The classes for user objects and fuel rate quotes are located in the Models folder of the project.

The project uses InMemoryDatabase from the EntityFrameworkCore package to store data. External database to be determined.

Missing components as of 3/4/22: Login module with validation and Fuel Price module with details.