﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FuelRateQuotes.Models;
using FuelRateQuotes.Services;

namespace FuelRateQuotes.Controllers
{
    [Route("api/UserItems")]
    [ApiController]
    public class UserItemsController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserItemsController(IUserService userService)
        {
            this._userService = userService;
        }

        // GET: api/UserItems
        [HttpGet]
        public ActionResult<List<UserItem>> Get() =>
            _userService.Get();

        // GET: api/UserItems/5
        [HttpGet("{id:length(24)}", Name = "GetUserItem")]
        public ActionResult<UserItem> Get([FromRoute] string id)
        {
            var userItem = _userService.Get(id);

            if (userItem == null || id == null)
            {
                return NotFound();
            }

            return Ok(userItem);
        }

        // POST: api/UserItems
        [HttpPost]
        public ActionResult<UserItem> Create([FromBody] UserItem userItem)
        {
            _userService.Create(userItem);

            return CreatedAtRoute("GetUserItem", new { id = userItem.id.ToString() }, userItem);
        }

        // PUT: api/UserItems
        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, [FromBody] UserItem userItemIn)
        {
            var user = _userService.Get(id);

            if (user == null || userItemIn.id == null)
            {
                return NotFound();
            }

            _userService.Update(id, userItemIn);

            return NoContent();
        }

        // DELETE: api/UserItems
        [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id)
        {
            var userItem = _userService.Get(id);

            if (userItem == null || id == null)
            {
                return NotFound();
            }

            _userService.Remove(id);

            return NoContent();
        }     
    }
}