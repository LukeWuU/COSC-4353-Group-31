Latest prototype of the FuelRateQuotes project, target framework upgraded to .NET Core 5.0 along with the necessary packages.

Template based on Microsoft tutorial "Tutorial: Create a web API with ASP.NET Core and MongoDB", .NET Core version 5.0.

MongoDB.Driver v2.15.0 installed as the desired database.

The Web API fulfills basic CRUD actions for Client Profile Management, verified through testing in the launch URL: api/UserItems.

The Create and Read functions with index.html perform successfully. The Delete and Edit functions are still in progress.
 
The classes for user objects and fuel rate quotes are located in the Models folder of the project.

The project was currently tested locally using MongoDB v5.0.6 to store data.

The following NuGet packages have been recently installed: XUnit and FakeItEasy for unit testing purposes.

After multiple edits and refactoring, the current unit tests have all passed.

Unit tests initially failed due to constructor error in creating fake type of UserService from FuelRateQuotes.Services.

Upon using the AddSingleton() method in Startup.cs, both IUserService and UserService perform successfully.

For unit testing, the IUserService class was used in FuelRateQuotes.Controller.

For Postman testing or frontend connectivity testing (index.html), UserService was used in FuelRateQuotes.Controller.

Code coverage was provided using dotCover from JetBrains trial installation.

Missing components as of 4/10/22: 

- Login module with stronger validation measures

- Client profile editing capabilities and edit displays

- Client profile deletion capabilities (performed successfully in previous prototype using InMemoryDatabase)

- Fuel Price module with implementation