﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FuelRateQuotes.Models;
using System.Web;

namespace FuelRateQuotes.Controllers
{
    public class TestControllers : testUsers
    {
        List<testUsers> clients = new List<testUsers>();

        public TestControllers() { }

        public TestControllers(List<testUsers> users)
        {
            this.clients = users;
        }

        public IEnumerable<testUsers> GetAllClients()
        {
            return clients;
        }

        public async Task<IEnumerable<testUsers>> GetAllClientsAsync()
        {
            return await Task.FromResult(GetAllClients());
        }
    }
}