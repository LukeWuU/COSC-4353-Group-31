﻿using System;

namespace FuelRateQuotes.Models
{
    public class testUsers
    {
        public string id { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string address2 { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string zipcode { get; set; }
        public string username { get; set; }
        private string password { get; set; }

    }
}