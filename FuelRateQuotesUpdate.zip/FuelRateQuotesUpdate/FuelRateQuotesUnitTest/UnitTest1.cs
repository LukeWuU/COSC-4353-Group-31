using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using FakeItEasy;
using FuelRateQuotes.Controllers;
using FuelRateQuotes.Models;
using FuelRateQuotes.Services;
using Microsoft.AspNetCore.Mvc;
using Assert = Xunit.Assert;

namespace FuelRateQuotesUnitTest
{
    [TestClass]
    public class UserItemsControllerTest
    {
        [TestMethod]
        public void Get_Users_Should_Return_Correct_User()
        {
            //Arrange
            var mockUserItemList = new List<UserItem> { new UserItem { name = "Name", city = "Houston" } };
            var dataService = A.Fake<IUserService>();
            UserItemsController controller = new(dataService);
            A.CallTo(() => dataService.Get()).Returns(mockUserItemList);

            //Act
            var actionResult = controller.Get();

            //Assert
            var result = actionResult.Value;
            Assert.Equal(result.FirstOrDefault().name, mockUserItemList.FirstOrDefault().name);
            Assert.Equal(result.FirstOrDefault().city, mockUserItemList.FirstOrDefault().city);
        }

        [TestMethod]
        public void Get_Users_Should_Return_No_Results()
        {
            //Arrange
            int count = 0;
            var mockUserItemList = new List<UserItem> {};
            var dataService = A.Fake<IUserService>();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Get()).Returns(mockUserItemList);

            //Act
            var actionResult = controller.Get();

            //Assert
            var result = actionResult.Value;
            Assert.Equal(count, result.Count);
        }

        [TestMethod]
        public void Get_Users_Should_Return_One_Result()
        {
            //Arrange
            int count = 1;
            var mockUserItemList = new List<UserItem> { new UserItem { id = "1", name = "testName", city = "n/a" } };
            var dataService = A.Fake<IUserService>();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Get()).Returns(mockUserItemList);

            //Act
            var actionResult = controller.Get();

            //Assert
            var result = actionResult.Value;
            Assert.Equal(count, result.Count);
        }

        [TestMethod]
        public void GetUserById_Should_Return_Correct_User()
        {
            //Arrange
            var mockUserItemList = new List<UserItem> { new UserItem { id = "6ab3dc6bb6abc09ec1abc450" }};
            var dataService = A.Fake<IUserService>();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Get()).Returns(mockUserItemList);

            //Act
            var actionResult = controller.Get(mockUserItemList.FirstOrDefault().id);

            //Assert
            var result = actionResult.Result as OkObjectResult;
            Assert.NotNull(result.Value);
        }

        [TestMethod]
        public void Get_User_With_Null_Id_Should_Return_Not_Found()
        {
            //Arrange
            var mockUserItemList = new List<UserItem> { new UserItem { name = "6ab3dc6bb6abc09ec1abc450" } };
            var dataService = A.Fake<IUserService>();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Get()).Returns(mockUserItemList);

            //Act
            var actionResult = controller.Get(mockUserItemList.FirstOrDefault().id);

            //Assert
            var result = actionResult.Result as NotFoundResult;
            Assert.Equal(404, result.StatusCode);
        }

        [TestMethod]
        public void CreateUser_Should_Create_Correct_User()
        {
            //Arrange
            var testItem = new UserItem { id = "6ab3dc6bb6abl09ec1abc451", name = "Newton", username = "Newton98"};
            var dataService = A.Fake<IUserService>();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Create(testItem)).Returns(testItem);

            //Act
            var actionResult = controller.Create(testItem);

            //Assert
            var result = actionResult.Result;
            Assert.NotNull(result);
        }

        [TestMethod]
        public void Create_With_Invalid_ModelState_Should_Return_Bad_Request()
        {
            //Arrange
            var testItem = new UserItem { id = " ", name = " ", username = " " };
            var dataService = A.Fake<IUserService>();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Create(testItem)).Returns(testItem);

            //Act
            var actionResult = controller.Create(testItem);

            //Assert
            var result = actionResult.Result;
            Assert.NotNull(result);
        }

        [TestMethod]
        public void Update_User_Should_Return_Ok_Result()
        {
            //Arrange
            var testItem = new UserItem { id = "6ab3dc6bb6abl09ec1abc450", name = "Newton", username = "Newton98" };
            var dataService = A.Fake<IUserService>();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Update(testItem.id, testItem)).DoesNothing();

            //Act
            var actionResult = controller.Update(testItem.id, testItem);

            //Assert
            var result = actionResult as NoContentResult;
            Assert.Equal(204, result.StatusCode);
        }

        [TestMethod]
        public void Update_User_with_No_ID_Should_Return_Null_Result()
        {
            //Arrange
            var testItem = new UserItem { name = "Newton", username = "Newton98" };
            var dataService = A.Fake<IUserService>();
            var fakeItems = A.CollectionOfFake<UserItem>(3).AsEnumerable();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Update(testItem.id, testItem));

            //Act
            var actionResult = controller.Update(testItem.id, testItem);

            //Assert
            var result = actionResult as NotFoundObjectResult;
            Assert.Null(result);
        }

        [TestMethod]
        public void DeleteUser_Should_Return_Ok_as_NotNull_Result()
        {
            //Arrange
            var testItem = new UserItem { id = "6ab3dc6bb6abl09ec1abc451", name = "Newton", address = "54 Houston St." };
            var dataService = A.Fake<IUserService>();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Remove(testItem)).DoesNothing();

            //Act
            var actionResult = controller.Delete(testItem.id);

            //Assert
            var result = actionResult as NoContentResult;
            Assert.Equal(204, result.StatusCode);
        }

        [TestMethod]
        public void DeleteUserItem_Should_Return_Ok_as_NotNull_Result()
        {
            //Arrange
            var testItem = new UserItem { id = "6ab3dc6bb6abl09ec1abc451", name = "Newton", address = "54 Houston St." };
            var dataService = A.Fake<IUserService>();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Remove(testItem)).DoesNothing();

            //Act
            var actionResult = controller.Delete(testItem.id);

            //Assert
            var result = actionResult as NoContentResult;
            Assert.Equal(204, result.StatusCode);
        }

        [TestMethod]
        public void DeleteNullID_Should_Return_Ok_as_Not_Found()
        {
            //Arrange
            var testItem = new UserItem { name = "Newton", address = "54 Houston St." };
            var dataService = A.Fake<IUserService>();
            var controller = new UserItemsController(dataService);
            A.CallTo(() => dataService.Remove(testItem)).DoesNothing();

            //Act
            var actionResult = controller.Delete(testItem.id);

            //Assert
            var result = actionResult as NotFoundResult;
            Assert.Equal(404, result.StatusCode);
        }
    }
}
