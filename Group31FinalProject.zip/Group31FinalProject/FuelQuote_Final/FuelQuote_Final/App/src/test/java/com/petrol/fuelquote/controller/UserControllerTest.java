package com.petrol.fuelquote.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.petrol.fuelquote.model.User;
import com.petrol.fuelquote.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static net.bytebuddy.matcher.ElementMatchers.is;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.AdditionalAnswers.returnsFirstArg;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
class UserControllerTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    MockMvc mockMvc;

    @Autowired
    ObjectMapper objectMapper;

    @MockBean
    UserRepository userRepository1;

    User User_1 = new User(1l,"tess1", "87tfGe4!", null,
            "Tess Naim", "123 Bis St.",
            "n/a", "Baker", "WA", "12233", null);

    User User_2 = new User(2l,"nellg83", "7pu#gv0", null,
            "Nell Gresham", "6817 Rainy Ave.",
            "45 University Blvd.", "Austin", "TX", "77084", null);

    User User_3 = new User(3l,"o0yasqueen0o", "r3wY&q", null,
            "Morris Barnes", "900 Hidalgo St.",
            "n/a", "Hepburn", "NY", "56642-6401", null);

    @Test
    void userRegistrationDto() throws Exception {
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/",
                String.class)).contains("username");
    }

    @Test
    void showRegistrationForm() throws Exception {
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/",
                String.class)).contains("username");
    }

    @Test
    void registerUser() throws Exception {
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/",
                String.class)).contains("username");
    }

    @Test
    void profile() throws Exception {
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/",
                String.class)).contains("username");
    }

    @Test
    void saveRegFormShouldReturnNotNull() {
        UserRepository userRepository = Mockito.mock(UserRepository.class);
        when(userRepository.save(any(User.class))).then(returnsFirstArg());
        userRepository.findByUsername(User_1.getUsername());
        assertThat(User_1.getUsername()).isNotNull();
    }

    @Test
    void showRegForm() throws Exception{
        UserController userController = Mockito.mock(UserController.class);
        Mockito.when(userController.showRegistrationForm()).thenReturn(String.valueOf(returnsFirstArg()));
        mockMvc.perform(MockMvcRequestBuilders
                .get("/registration")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void getUsers_AllUsers() throws Exception{
        List<User> users = new ArrayList<>(Arrays.asList(User_1, User_2, User_3));
        Mockito.when(userRepository1.findAll()).thenReturn(users);
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/login")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void readUsers() throws Exception{
        List<User> users = new ArrayList<>(Arrays.asList(User_1, User_2, User_3));
        UserController userController = Mockito.mock(UserController.class);
        Mockito.when(userController.readUsers()).thenReturn(users);
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/login")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void updateUser() throws Exception {
        UserController userController = Mockito.mock(UserController.class);
        userController.updateUser(User_1.getId(), User_1);
    } //Yet to be properly tested due to unavailable url for update request

    @Test
    void deleteNullUser() throws Exception {
        Mockito.when(userRepository1.findById(51L)).thenReturn(null);

        mockMvc.perform(MockMvcRequestBuilders
                .delete("/login")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError());
    } //Yet to be properly tested due to unavailable url for delete request

    @Test
    void deleteUser() throws Exception {
        Mockito.when(userRepository1.findById(User_2.getId())).thenReturn(Optional.of(User_2));
        mockMvc.perform(MockMvcRequestBuilders
                .delete("/user/2")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError());
    } //Yet to be properly tested due to unavailable url for delete request
}