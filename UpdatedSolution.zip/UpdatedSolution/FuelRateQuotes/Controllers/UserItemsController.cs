﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FuelRateQuotes.Models;
using FuelRateQuotes.Services;

namespace FuelRateQuotes.Controllers
{
    [Route("api/UserItems")]
    [ApiController]
    public class UserItemsController : ControllerBase
    {
        private readonly UserService _userService;

        public UserItemsController(UserService userService)
        {
            _userService = userService;
        }

        // GET: api/UserItems
        [HttpGet]
        public ActionResult<List<UserItem>> Get() =>
            _userService.Get();

        // GET: api/UserItems/5
        [HttpGet("{id:length(24)}", Name = "GetUserItem")]
        public ActionResult<UserItem> Get([FromRoute] string id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var userItem = _userService.Get(id);

            if (userItem == null)
            {
                return NotFound();
            }

            return Ok(userItem);
        }

        // PUT: api/UserItems/5
        [HttpPut("{id:length(24)}")]
        public IActionResult Update(string id, UserItem userItemIn)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            
            var user = _userService.Get(id);

            if (user == null)
            {
                return NotFound();
            }

            _userService.Update(id, userItemIn);
            
            return NoContent();
        }

        // POST: api/UserItems
        [HttpPost]
        public ActionResult<UserItem> Create([FromBody] UserItem userItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _userService.Create(userItem);

            return CreatedAtRoute("GetUserItem", new { id = userItem.id.ToString() }, userItem);
        }

        // DELETE: api/UserItems/5
        [HttpDelete("{id:length(24)}")]
        public IActionResult Delete(string id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var userItem = _userService.Get(id);

            if (userItem == null)
            {
                return NotFound();
            }

            _userService.Remove(id);

            return Ok(userItem);
        }
    }
}