Latest prototype of the FuelRateQuotes project, target framework upgraded to .NET Core 5.0 along with the necessary packages.

Template based on Microsoft tutorial "Tutorial: Create a web API with ASP.NET Core and MongoDB", .NET Core version 5.0.

MongoDB.Driver v2.15.0 installed as the desired database.

The Web API fulfills basic CRUD actions for Client Profile Management, verified through unit testing in the launch URL: index.html.

The Create and Read functions under Client Manangement perform successfully. The Delete and Edit function are still in progress.
 
The classes for user objects and fuel rate quotes are located in the Models folder of the project.

The project currently was tested locally using MongoDB v5.0.6 to store data.

Unit testing to be determined.

Code coverage using OpenCover and Report Generator to be determined.

Missing components as of 4/3/22: 

- Login module with stronger validation measures

- Client profile editing capabilities and edit displays

- Client profile deletion capabilities (performed successfully in previous prototype)

- Fuel Price module with implementation

- Unit testing

- Code Coverage report for unit tests